﻿namespace Радченко
{
    partial class sign_service
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.sign = new Guna.UI2.WinForms.Guna2Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Parik = new Guna.UI2.WinForms.Guna2RadioButton();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.woomparik = new Guna.UI2.WinForms.Guna2RadioButton();
            this.kinderparik = new Guna.UI2.WinForms.Guna2RadioButton();
            this.manparik = new Guna.UI2.WinForms.Guna2RadioButton();
            this.choiseparik = new Guna.UI2.WinForms.Guna2RadioButton();
            this.coloringparik = new Guna.UI2.WinForms.Guna2RadioButton();
            this.colorirovanie = new Guna.UI2.WinForms.Guna2RadioButton();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.daywakeup = new Guna.UI2.WinForms.Guna2RadioButton();
            this.Visazhist = new Guna.UI2.WinForms.Guna2RadioButton();
            this.eveningwakeup = new Guna.UI2.WinForms.Guna2RadioButton();
            this.weddingwakeup = new Guna.UI2.WinForms.Guna2RadioButton();
            this.guna2RadioButton11 = new Guna.UI2.WinForms.Guna2RadioButton();
            this.guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2RadioButton12 = new Guna.UI2.WinForms.Guna2RadioButton();
            this.classicmanicure = new Guna.UI2.WinForms.Guna2RadioButton();
            this.evromanicure = new Guna.UI2.WinForms.Guna2RadioButton();
            this.apparatmanicure = new Guna.UI2.WinForms.Guna2RadioButton();
            this.spamanicure = new Guna.UI2.WinForms.Guna2RadioButton();
            this.varnishmanicure = new Guna.UI2.WinForms.Guna2RadioButton();
            this.apparatpedicure = new Guna.UI2.WinForms.Guna2RadioButton();
            this.classicpedicure = new Guna.UI2.WinForms.Guna2RadioButton();
            this.FIO_Client = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Panel1.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.guna2Panel3.SuspendLayout();
            this.guna2Panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Button1
            // 
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(13, 393);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(180, 45);
            this.guna2Button1.TabIndex = 0;
            this.guna2Button1.Text = "Вернуться";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.AutoScroll = true;
            this.guna2Panel1.Controls.Add(this.guna2RadioButton12);
            this.guna2Panel1.Controls.Add(this.guna2Panel4);
            this.guna2Panel1.Controls.Add(this.guna2RadioButton11);
            this.guna2Panel1.Controls.Add(this.Visazhist);
            this.guna2Panel1.Controls.Add(this.guna2Panel3);
            this.guna2Panel1.Controls.Add(this.guna2Panel2);
            this.guna2Panel1.Controls.Add(this.Parik);
            this.guna2Panel1.Controls.Add(this.label1);
            this.guna2Panel1.Location = new System.Drawing.Point(13, 13);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(775, 374);
            this.guna2Panel1.TabIndex = 1;
            // 
            // sign
            // 
            this.sign.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.sign.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.sign.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.sign.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.sign.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.sign.ForeColor = System.Drawing.Color.White;
            this.sign.Location = new System.Drawing.Point(199, 393);
            this.sign.Name = "sign";
            this.sign.Size = new System.Drawing.Size(180, 45);
            this.sign.TabIndex = 2;
            this.sign.Text = "Записаться";
            this.sign.Click += new System.EventHandler(this.sign_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(302, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Выберите услугу";
            // 
            // Parik
            // 
            this.Parik.AutoSize = true;
            this.Parik.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Parik.CheckedState.BorderThickness = 0;
            this.Parik.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Parik.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Parik.CheckedState.InnerOffset = -4;
            this.Parik.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Parik.Location = new System.Drawing.Point(3, 32);
            this.Parik.Name = "Parik";
            this.Parik.Size = new System.Drawing.Size(205, 24);
            this.Parik.TabIndex = 1;
            this.Parik.Text = "Парикмахерские услуги";
            this.Parik.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Parik.UncheckedState.BorderThickness = 2;
            this.Parik.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Parik.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.Parik.CheckedChanged += new System.EventHandler(this.Parik_CheckedChanged);
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.colorirovanie);
            this.guna2Panel2.Controls.Add(this.coloringparik);
            this.guna2Panel2.Controls.Add(this.choiseparik);
            this.guna2Panel2.Controls.Add(this.manparik);
            this.guna2Panel2.Controls.Add(this.kinderparik);
            this.guna2Panel2.Controls.Add(this.woomparik);
            this.guna2Panel2.Location = new System.Drawing.Point(8, 62);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(293, 163);
            this.guna2Panel2.TabIndex = 2;
            this.guna2Panel2.Visible = false;
            // 
            // woomparik
            // 
            this.woomparik.AutoSize = true;
            this.woomparik.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.woomparik.CheckedState.BorderThickness = 0;
            this.woomparik.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.woomparik.CheckedState.InnerColor = System.Drawing.Color.White;
            this.woomparik.CheckedState.InnerOffset = -4;
            this.woomparik.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.woomparik.Location = new System.Drawing.Point(4, 4);
            this.woomparik.Name = "woomparik";
            this.woomparik.Size = new System.Drawing.Size(140, 20);
            this.woomparik.TabIndex = 0;
            this.woomparik.Text = "Женская стрижка";
            this.woomparik.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.woomparik.UncheckedState.BorderThickness = 2;
            this.woomparik.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.woomparik.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // kinderparik
            // 
            this.kinderparik.AutoSize = true;
            this.kinderparik.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.kinderparik.CheckedState.BorderThickness = 0;
            this.kinderparik.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.kinderparik.CheckedState.InnerColor = System.Drawing.Color.White;
            this.kinderparik.CheckedState.InnerOffset = -4;
            this.kinderparik.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.kinderparik.Location = new System.Drawing.Point(4, 31);
            this.kinderparik.Name = "kinderparik";
            this.kinderparik.Size = new System.Drawing.Size(135, 20);
            this.kinderparik.TabIndex = 1;
            this.kinderparik.Text = "Детская стрижка";
            this.kinderparik.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.kinderparik.UncheckedState.BorderThickness = 2;
            this.kinderparik.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.kinderparik.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // manparik
            // 
            this.manparik.AutoSize = true;
            this.manparik.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.manparik.CheckedState.BorderThickness = 0;
            this.manparik.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.manparik.CheckedState.InnerColor = System.Drawing.Color.White;
            this.manparik.CheckedState.InnerOffset = -4;
            this.manparik.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.manparik.Location = new System.Drawing.Point(4, 57);
            this.manparik.Name = "manparik";
            this.manparik.Size = new System.Drawing.Size(139, 20);
            this.manparik.TabIndex = 2;
            this.manparik.Text = "Мужская стрижка";
            this.manparik.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.manparik.UncheckedState.BorderThickness = 2;
            this.manparik.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.manparik.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // choiseparik
            // 
            this.choiseparik.AutoSize = true;
            this.choiseparik.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.choiseparik.CheckedState.BorderThickness = 0;
            this.choiseparik.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.choiseparik.CheckedState.InnerColor = System.Drawing.Color.White;
            this.choiseparik.CheckedState.InnerOffset = -4;
            this.choiseparik.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.choiseparik.Location = new System.Drawing.Point(4, 84);
            this.choiseparik.Name = "choiseparik";
            this.choiseparik.Size = new System.Drawing.Size(278, 20);
            this.choiseparik.TabIndex = 3;
            this.choiseparik.Text = "Выбор прически(обращаться в салоне)";
            this.choiseparik.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.choiseparik.UncheckedState.BorderThickness = 2;
            this.choiseparik.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.choiseparik.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // coloringparik
            // 
            this.coloringparik.AutoSize = true;
            this.coloringparik.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.coloringparik.CheckedState.BorderThickness = 0;
            this.coloringparik.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.coloringparik.CheckedState.InnerColor = System.Drawing.Color.White;
            this.coloringparik.CheckedState.InnerOffset = -4;
            this.coloringparik.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.coloringparik.Location = new System.Drawing.Point(4, 111);
            this.coloringparik.Name = "coloringparik";
            this.coloringparik.Size = new System.Drawing.Size(115, 20);
            this.coloringparik.TabIndex = 4;
            this.coloringparik.Text = "Окрашивание";
            this.coloringparik.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.coloringparik.UncheckedState.BorderThickness = 2;
            this.coloringparik.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.coloringparik.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // colorirovanie
            // 
            this.colorirovanie.AutoSize = true;
            this.colorirovanie.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.colorirovanie.CheckedState.BorderThickness = 0;
            this.colorirovanie.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.colorirovanie.CheckedState.InnerColor = System.Drawing.Color.White;
            this.colorirovanie.CheckedState.InnerOffset = -4;
            this.colorirovanie.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.colorirovanie.Location = new System.Drawing.Point(4, 137);
            this.colorirovanie.Name = "colorirovanie";
            this.colorirovanie.Size = new System.Drawing.Size(129, 20);
            this.colorirovanie.TabIndex = 5;
            this.colorirovanie.Text = "Колорирование";
            this.colorirovanie.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.colorirovanie.UncheckedState.BorderThickness = 2;
            this.colorirovanie.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.colorirovanie.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.colorirovanie.CheckedChanged += new System.EventHandler(this.guna2RadioButton7_CheckedChanged);
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.Controls.Add(this.weddingwakeup);
            this.guna2Panel3.Controls.Add(this.eveningwakeup);
            this.guna2Panel3.Controls.Add(this.daywakeup);
            this.guna2Panel3.Location = new System.Drawing.Point(522, 66);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.Size = new System.Drawing.Size(200, 85);
            this.guna2Panel3.TabIndex = 4;
            this.guna2Panel3.Visible = false;
            // 
            // daywakeup
            // 
            this.daywakeup.AutoSize = true;
            this.daywakeup.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.daywakeup.CheckedState.BorderThickness = 0;
            this.daywakeup.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.daywakeup.CheckedState.InnerColor = System.Drawing.Color.White;
            this.daywakeup.CheckedState.InnerOffset = -4;
            this.daywakeup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.daywakeup.Location = new System.Drawing.Point(4, 4);
            this.daywakeup.Name = "daywakeup";
            this.daywakeup.Size = new System.Drawing.Size(133, 20);
            this.daywakeup.TabIndex = 0;
            this.daywakeup.Text = "Дневной макияж";
            this.daywakeup.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.daywakeup.UncheckedState.BorderThickness = 2;
            this.daywakeup.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.daywakeup.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // Visazhist
            // 
            this.Visazhist.AutoSize = true;
            this.Visazhist.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Visazhist.CheckedState.BorderThickness = 0;
            this.Visazhist.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Visazhist.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Visazhist.CheckedState.InnerOffset = -4;
            this.Visazhist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Visazhist.Location = new System.Drawing.Point(513, 40);
            this.Visazhist.Name = "Visazhist";
            this.Visazhist.Size = new System.Drawing.Size(163, 24);
            this.Visazhist.TabIndex = 5;
            this.Visazhist.Text = "Услуги визажиста";
            this.Visazhist.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Visazhist.UncheckedState.BorderThickness = 2;
            this.Visazhist.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Visazhist.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.Visazhist.CheckedChanged += new System.EventHandler(this.guna2RadioButton8_CheckedChanged);
            // 
            // eveningwakeup
            // 
            this.eveningwakeup.AutoSize = true;
            this.eveningwakeup.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.eveningwakeup.CheckedState.BorderThickness = 0;
            this.eveningwakeup.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.eveningwakeup.CheckedState.InnerColor = System.Drawing.Color.White;
            this.eveningwakeup.CheckedState.InnerOffset = -4;
            this.eveningwakeup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.eveningwakeup.Location = new System.Drawing.Point(4, 27);
            this.eveningwakeup.Name = "eveningwakeup";
            this.eveningwakeup.Size = new System.Drawing.Size(141, 20);
            this.eveningwakeup.TabIndex = 1;
            this.eveningwakeup.Text = "Вечерний макияж";
            this.eveningwakeup.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.eveningwakeup.UncheckedState.BorderThickness = 2;
            this.eveningwakeup.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.eveningwakeup.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // weddingwakeup
            // 
            this.weddingwakeup.AutoSize = true;
            this.weddingwakeup.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.weddingwakeup.CheckedState.BorderThickness = 0;
            this.weddingwakeup.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.weddingwakeup.CheckedState.InnerColor = System.Drawing.Color.White;
            this.weddingwakeup.CheckedState.InnerOffset = -4;
            this.weddingwakeup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.weddingwakeup.Location = new System.Drawing.Point(4, 53);
            this.weddingwakeup.Name = "weddingwakeup";
            this.weddingwakeup.Size = new System.Drawing.Size(150, 20);
            this.weddingwakeup.TabIndex = 2;
            this.weddingwakeup.Text = "Свадебный макияж";
            this.weddingwakeup.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.weddingwakeup.UncheckedState.BorderThickness = 2;
            this.weddingwakeup.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.weddingwakeup.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // guna2RadioButton11
            // 
            this.guna2RadioButton11.AutoSize = true;
            this.guna2RadioButton11.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2RadioButton11.CheckedState.BorderThickness = 0;
            this.guna2RadioButton11.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2RadioButton11.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2RadioButton11.CheckedState.InnerOffset = -4;
            this.guna2RadioButton11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2RadioButton11.Location = new System.Drawing.Point(513, 241);
            this.guna2RadioButton11.Name = "guna2RadioButton11";
            this.guna2RadioButton11.Size = new System.Drawing.Size(93, 24);
            this.guna2RadioButton11.TabIndex = 6;
            this.guna2RadioButton11.Text = "Солярий";
            this.guna2RadioButton11.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2RadioButton11.UncheckedState.BorderThickness = 2;
            this.guna2RadioButton11.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2RadioButton11.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.guna2RadioButton11.CheckedChanged += new System.EventHandler(this.guna2RadioButton11_CheckedChanged);
            // 
            // guna2Panel4
            // 
            this.guna2Panel4.Controls.Add(this.classicpedicure);
            this.guna2Panel4.Controls.Add(this.apparatpedicure);
            this.guna2Panel4.Controls.Add(this.varnishmanicure);
            this.guna2Panel4.Controls.Add(this.spamanicure);
            this.guna2Panel4.Controls.Add(this.apparatmanicure);
            this.guna2Panel4.Controls.Add(this.evromanicure);
            this.guna2Panel4.Controls.Add(this.classicmanicure);
            this.guna2Panel4.Location = new System.Drawing.Point(8, 274);
            this.guna2Panel4.Name = "guna2Panel4";
            this.guna2Panel4.Size = new System.Drawing.Size(293, 190);
            this.guna2Panel4.TabIndex = 7;
            this.guna2Panel4.Visible = false;
            // 
            // guna2RadioButton12
            // 
            this.guna2RadioButton12.AutoSize = true;
            this.guna2RadioButton12.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2RadioButton12.CheckedState.BorderThickness = 0;
            this.guna2RadioButton12.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2RadioButton12.CheckedState.InnerColor = System.Drawing.Color.White;
            this.guna2RadioButton12.CheckedState.InnerOffset = -4;
            this.guna2RadioButton12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2RadioButton12.Location = new System.Drawing.Point(3, 241);
            this.guna2RadioButton12.Name = "guna2RadioButton12";
            this.guna2RadioButton12.Size = new System.Drawing.Size(156, 24);
            this.guna2RadioButton12.TabIndex = 8;
            this.guna2RadioButton12.Text = "Ногтевой сервис";
            this.guna2RadioButton12.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2RadioButton12.UncheckedState.BorderThickness = 2;
            this.guna2RadioButton12.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.guna2RadioButton12.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.guna2RadioButton12.CheckedChanged += new System.EventHandler(this.guna2RadioButton12_CheckedChanged);
            // 
            // classicmanicure
            // 
            this.classicmanicure.AutoSize = true;
            this.classicmanicure.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.classicmanicure.CheckedState.BorderThickness = 0;
            this.classicmanicure.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.classicmanicure.CheckedState.InnerColor = System.Drawing.Color.White;
            this.classicmanicure.CheckedState.InnerOffset = -4;
            this.classicmanicure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.classicmanicure.Location = new System.Drawing.Point(4, 4);
            this.classicmanicure.Name = "classicmanicure";
            this.classicmanicure.Size = new System.Drawing.Size(179, 20);
            this.classicmanicure.TabIndex = 0;
            this.classicmanicure.Text = "Маникюр классический";
            this.classicmanicure.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.classicmanicure.UncheckedState.BorderThickness = 2;
            this.classicmanicure.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.classicmanicure.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // evromanicure
            // 
            this.evromanicure.AutoSize = true;
            this.evromanicure.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.evromanicure.CheckedState.BorderThickness = 0;
            this.evromanicure.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.evromanicure.CheckedState.InnerColor = System.Drawing.Color.White;
            this.evromanicure.CheckedState.InnerOffset = -4;
            this.evromanicure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.evromanicure.Location = new System.Drawing.Point(4, 30);
            this.evromanicure.Name = "evromanicure";
            this.evromanicure.Size = new System.Drawing.Size(174, 20);
            this.evromanicure.TabIndex = 1;
            this.evromanicure.Text = "Маникюр европейский";
            this.evromanicure.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.evromanicure.UncheckedState.BorderThickness = 2;
            this.evromanicure.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.evromanicure.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // apparatmanicure
            // 
            this.apparatmanicure.AutoSize = true;
            this.apparatmanicure.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.apparatmanicure.CheckedState.BorderThickness = 0;
            this.apparatmanicure.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.apparatmanicure.CheckedState.InnerColor = System.Drawing.Color.White;
            this.apparatmanicure.CheckedState.InnerOffset = -4;
            this.apparatmanicure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.apparatmanicure.Location = new System.Drawing.Point(4, 57);
            this.apparatmanicure.Name = "apparatmanicure";
            this.apparatmanicure.Size = new System.Drawing.Size(168, 20);
            this.apparatmanicure.TabIndex = 2;
            this.apparatmanicure.Text = "Маникюр аппаратный";
            this.apparatmanicure.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.apparatmanicure.UncheckedState.BorderThickness = 2;
            this.apparatmanicure.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.apparatmanicure.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // spamanicure
            // 
            this.spamanicure.AutoSize = true;
            this.spamanicure.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.spamanicure.CheckedState.BorderThickness = 0;
            this.spamanicure.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.spamanicure.CheckedState.InnerColor = System.Drawing.Color.White;
            this.spamanicure.CheckedState.InnerOffset = -4;
            this.spamanicure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.spamanicure.Location = new System.Drawing.Point(4, 84);
            this.spamanicure.Name = "spamanicure";
            this.spamanicure.Size = new System.Drawing.Size(92, 20);
            this.spamanicure.TabIndex = 3;
            this.spamanicure.Text = "SPA - уход";
            this.spamanicure.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.spamanicure.UncheckedState.BorderThickness = 2;
            this.spamanicure.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.spamanicure.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // varnishmanicure
            // 
            this.varnishmanicure.AutoSize = true;
            this.varnishmanicure.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.varnishmanicure.CheckedState.BorderThickness = 0;
            this.varnishmanicure.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.varnishmanicure.CheckedState.InnerColor = System.Drawing.Color.White;
            this.varnishmanicure.CheckedState.InnerOffset = -4;
            this.varnishmanicure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.varnishmanicure.Location = new System.Drawing.Point(4, 111);
            this.varnishmanicure.Name = "varnishmanicure";
            this.varnishmanicure.Size = new System.Drawing.Size(133, 20);
            this.varnishmanicure.TabIndex = 4;
            this.varnishmanicure.Text = "Покрытие лаком";
            this.varnishmanicure.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.varnishmanicure.UncheckedState.BorderThickness = 2;
            this.varnishmanicure.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.varnishmanicure.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // apparatpedicure
            // 
            this.apparatpedicure.AutoSize = true;
            this.apparatpedicure.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.apparatpedicure.CheckedState.BorderThickness = 0;
            this.apparatpedicure.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.apparatpedicure.CheckedState.InnerColor = System.Drawing.Color.White;
            this.apparatpedicure.CheckedState.InnerOffset = -4;
            this.apparatpedicure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.apparatpedicure.Location = new System.Drawing.Point(4, 138);
            this.apparatpedicure.Name = "apparatpedicure";
            this.apparatpedicure.Size = new System.Drawing.Size(167, 20);
            this.apparatpedicure.TabIndex = 5;
            this.apparatpedicure.Text = "Педикюр аппаратный";
            this.apparatpedicure.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.apparatpedicure.UncheckedState.BorderThickness = 2;
            this.apparatpedicure.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.apparatpedicure.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // classicpedicure
            // 
            this.classicpedicure.AutoSize = true;
            this.classicpedicure.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.classicpedicure.CheckedState.BorderThickness = 0;
            this.classicpedicure.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.classicpedicure.CheckedState.InnerColor = System.Drawing.Color.White;
            this.classicpedicure.CheckedState.InnerOffset = -4;
            this.classicpedicure.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.classicpedicure.Location = new System.Drawing.Point(4, 165);
            this.classicpedicure.Name = "classicpedicure";
            this.classicpedicure.Size = new System.Drawing.Size(287, 20);
            this.classicpedicure.TabIndex = 6;
            this.classicpedicure.Text = "Педикюр классический покрытие лаком";
            this.classicpedicure.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.classicpedicure.UncheckedState.BorderThickness = 2;
            this.classicpedicure.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.classicpedicure.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // FIO_Client
            // 
            this.FIO_Client.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.FIO_Client.DefaultText = "";
            this.FIO_Client.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.FIO_Client.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.FIO_Client.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.FIO_Client.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.FIO_Client.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.FIO_Client.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.FIO_Client.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.FIO_Client.Location = new System.Drawing.Point(386, 393);
            this.FIO_Client.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FIO_Client.Name = "FIO_Client";
            this.FIO_Client.PasswordChar = '\0';
            this.FIO_Client.PlaceholderText = "Введите ФИО";
            this.FIO_Client.SelectedText = "";
            this.FIO_Client.Size = new System.Drawing.Size(401, 45);
            this.FIO_Client.TabIndex = 3;
            this.FIO_Client.TextChanged += new System.EventHandler(this.FIO_Client_TextChanged);
            // 
            // sign_service
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.FIO_Client);
            this.Controls.Add(this.sign);
            this.Controls.Add(this.guna2Panel1);
            this.Controls.Add(this.guna2Button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "sign_service";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Запись на услугу";
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            this.guna2Panel2.ResumeLayout(false);
            this.guna2Panel2.PerformLayout();
            this.guna2Panel3.ResumeLayout(false);
            this.guna2Panel3.PerformLayout();
            this.guna2Panel4.ResumeLayout(false);
            this.guna2Panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2RadioButton Parik;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button sign;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2RadioButton colorirovanie;
        private Guna.UI2.WinForms.Guna2RadioButton coloringparik;
        private Guna.UI2.WinForms.Guna2RadioButton choiseparik;
        private Guna.UI2.WinForms.Guna2RadioButton manparik;
        private Guna.UI2.WinForms.Guna2RadioButton kinderparik;
        private Guna.UI2.WinForms.Guna2RadioButton woomparik;
        private Guna.UI2.WinForms.Guna2RadioButton Visazhist;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2RadioButton weddingwakeup;
        private Guna.UI2.WinForms.Guna2RadioButton eveningwakeup;
        private Guna.UI2.WinForms.Guna2RadioButton daywakeup;
        private Guna.UI2.WinForms.Guna2RadioButton guna2RadioButton12;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2RadioButton classicpedicure;
        private Guna.UI2.WinForms.Guna2RadioButton apparatpedicure;
        private Guna.UI2.WinForms.Guna2RadioButton varnishmanicure;
        private Guna.UI2.WinForms.Guna2RadioButton spamanicure;
        private Guna.UI2.WinForms.Guna2RadioButton apparatmanicure;
        private Guna.UI2.WinForms.Guna2RadioButton evromanicure;
        private Guna.UI2.WinForms.Guna2RadioButton classicmanicure;
        private Guna.UI2.WinForms.Guna2RadioButton guna2RadioButton11;
        private Guna.UI2.WinForms.Guna2TextBox FIO_Client;
    }
}