﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Радченко
{
    public partial class sign_service : Form
    {
        string connectrionString = "Data Source=0_311_2;Initial Catalog=Radchenko_examen;Integrated Security=True"; //Строка соединения

        public sign_service()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void guna2RadioButton7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Parik_CheckedChanged(object sender, EventArgs e)
        {
            guna2Panel2.Visible = true;
            guna2Panel3.Visible = false;
            guna2Panel4.Visible = false;
        }

        private void guna2RadioButton8_CheckedChanged(object sender, EventArgs e)
        {
            guna2Panel2.Visible = false;
            guna2Panel3.Visible = true;
            guna2Panel4.Visible = false;
        }

        private void FIO_Client_TextChanged(object sender, EventArgs e)
        {

        }

        private void sign_Click(object sender, EventArgs e) //Попытка сделать запись для клиента
        {
            //if()
            //{
            //    SqlConnection con = new SqlConnection(connectrionString);
            //    con.Open();
            //    SqlCommand cmd = new SqlCommand();
            //    cmd.Connection = con;
            //    cmd.CommandText = "INSERT INTO Entry VALUES (@FIO_Client, @Name_Services)";

            //}

        }

        private void guna2RadioButton12_CheckedChanged(object sender, EventArgs e)
        {
            guna2Panel2.Visible = false;
            guna2Panel3.Visible = false;
            guna2Panel4.Visible = true;
        }

        private void guna2RadioButton11_CheckedChanged(object sender, EventArgs e)
        {
            guna2Panel2.Visible = false;
            guna2Panel3.Visible = false;
            guna2Panel4.Visible = false;
        }
    }
}
