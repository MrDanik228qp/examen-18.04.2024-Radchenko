﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Радченко
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Тут будет содержаться информация о салоне");
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Autorization autorization = new Autorization();
            Hide();
            autorization.ShowDialog();
            Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
