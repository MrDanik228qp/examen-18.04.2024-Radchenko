﻿namespace Радченко
{
    partial class Autorization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Registration = new Guna.UI2.WinForms.Guna2Button();
            this.Enter = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.FIO = new Guna.UI2.WinForms.Guna2TextBox();
            this.Telephone_Client = new Guna.UI2.WinForms.Guna2TextBox();
            this.Email_Client = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.SuspendLayout();
            // 
            // Registration
            // 
            this.Registration.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Registration.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Registration.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Registration.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Registration.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Registration.ForeColor = System.Drawing.Color.White;
            this.Registration.Location = new System.Drawing.Point(161, 235);
            this.Registration.Name = "Registration";
            this.Registration.Size = new System.Drawing.Size(180, 45);
            this.Registration.TabIndex = 0;
            this.Registration.Text = "Зарегистрироваться";
            this.Registration.Click += new System.EventHandler(this.Registration_Click);
            // 
            // Enter
            // 
            this.Enter.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.Enter.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.Enter.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.Enter.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.Enter.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Enter.ForeColor = System.Drawing.Color.White;
            this.Enter.Location = new System.Drawing.Point(161, 184);
            this.Enter.Name = "Enter";
            this.Enter.Size = new System.Drawing.Size(180, 45);
            this.Enter.TabIndex = 1;
            this.Enter.Text = "Войти";
            this.Enter.Click += new System.EventHandler(this.Enter_Click);
            // 
            // guna2Button3
            // 
            this.guna2Button3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.Location = new System.Drawing.Point(161, 286);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.Size = new System.Drawing.Size(180, 45);
            this.guna2Button3.TabIndex = 2;
            this.guna2Button3.Text = "Пропустить";
            this.guna2Button3.Click += new System.EventHandler(this.guna2Button3_Click);
            // 
            // FIO
            // 
            this.FIO.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.FIO.DefaultText = "";
            this.FIO.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.FIO.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.FIO.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.FIO.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.FIO.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.FIO.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FIO.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.FIO.Location = new System.Drawing.Point(13, 13);
            this.FIO.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FIO.Name = "FIO";
            this.FIO.PasswordChar = '\0';
            this.FIO.PlaceholderText = "Введите ФИО";
            this.FIO.SelectedText = "";
            this.FIO.Size = new System.Drawing.Size(479, 50);
            this.FIO.TabIndex = 3;
            this.FIO.TextChanged += new System.EventHandler(this.FIO_TextChanged);
            // 
            // Telephone_Client
            // 
            this.Telephone_Client.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Telephone_Client.DefaultText = "";
            this.Telephone_Client.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Telephone_Client.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Telephone_Client.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Telephone_Client.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Telephone_Client.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Telephone_Client.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Telephone_Client.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Telephone_Client.Location = new System.Drawing.Point(13, 71);
            this.Telephone_Client.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Telephone_Client.Name = "Telephone_Client";
            this.Telephone_Client.PasswordChar = '\0';
            this.Telephone_Client.PlaceholderText = "Введите номер телефона";
            this.Telephone_Client.SelectedText = "";
            this.Telephone_Client.Size = new System.Drawing.Size(479, 50);
            this.Telephone_Client.TabIndex = 4;
            this.Telephone_Client.TextChanged += new System.EventHandler(this.Telephone_Client_TextChanged);
            // 
            // Email_Client
            // 
            this.Email_Client.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Email_Client.DefaultText = "";
            this.Email_Client.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Email_Client.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Email_Client.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Email_Client.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Email_Client.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Email_Client.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Email_Client.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Email_Client.Location = new System.Drawing.Point(13, 128);
            this.Email_Client.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Email_Client.Name = "Email_Client";
            this.Email_Client.PasswordChar = '\0';
            this.Email_Client.PlaceholderText = "Введите E-Mail";
            this.Email_Client.SelectedText = "";
            this.Email_Client.Size = new System.Drawing.Size(479, 50);
            this.Email_Client.TabIndex = 5;
            this.Email_Client.TextChanged += new System.EventHandler(this.Email_Client_TextChanged);
            // 
            // guna2Button4
            // 
            this.guna2Button4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.guna2Button4.ForeColor = System.Drawing.Color.White;
            this.guna2Button4.Location = new System.Drawing.Point(161, 337);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.Size = new System.Drawing.Size(180, 45);
            this.guna2Button4.TabIndex = 6;
            this.guna2Button4.Text = "Вернуться";
            this.guna2Button4.Click += new System.EventHandler(this.guna2Button4_Click);
            // 
            // Autorization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 450);
            this.Controls.Add(this.guna2Button4);
            this.Controls.Add(this.Email_Client);
            this.Controls.Add(this.Telephone_Client);
            this.Controls.Add(this.FIO);
            this.Controls.Add(this.guna2Button3);
            this.Controls.Add(this.Enter);
            this.Controls.Add(this.Registration);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Autorization";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Авторизация";
            this.Load += new System.EventHandler(this.Autorization_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button Registration;
        private Guna.UI2.WinForms.Guna2Button Enter;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2TextBox FIO;
        private Guna.UI2.WinForms.Guna2TextBox Telephone_Client;
        private Guna.UI2.WinForms.Guna2TextBox Email_Client;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
    }
}