﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Радченко
{
    public partial class Actions : Form
    {
        public Actions()
        {
            InitializeComponent();
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button10_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Тут будут отображаться контактные номера, местоположение и график работы");
        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Тут будет содержаться номер телефона");
        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {
            Service service = new Service();
            Hide();
            service.ShowDialog();
            Show();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            sign_service service = new sign_service();
            Hide();
            service.ShowDialog();
            Show();
        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {

        }
    }
}
