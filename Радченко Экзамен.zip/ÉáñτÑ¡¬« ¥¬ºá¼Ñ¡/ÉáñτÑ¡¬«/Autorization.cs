﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Радченко
{
    public partial class Autorization : Form
    {

        string connectrionString = "Data Source=0_311_2;Initial Catalog=Radchenko_examen;Integrated Security=True"; //Строка соединения

        public Autorization()
        {
            InitializeComponent();
            
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {
            Actions actions = new Actions();
            Hide();
            actions.ShowDialog();
            Show();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Autorization_Load(object sender, EventArgs e)
        {

        }

        private void FIO_TextChanged(object sender, EventArgs e)
        {

        }

        private void Enter_Click(object sender, EventArgs e) //Зарегистрированный пользователь(пока один)
        {
            if (FIO.Text == "Радченко Даниил Александрович" && Telephone_Client.Text == "89502083464" && Email_Client.Text == "daniil.radchenko.04@mail.ru")
            {
                Actions actions = new Actions();
                Hide();
                actions.ShowDialog();
                Show();
            }
        }

        private void Email_Client_TextChanged(object sender, EventArgs e)
        {

        }

        private void Telephone_Client_TextChanged(object sender, EventArgs e)
        {

        }

        private void Registration_Click(object sender, EventArgs e) //Добавление зарегистрированного пользователя в Базу Данных
        {           
            if (FIO.Text != "" && Telephone_Client.Text != "" && Email_Client.Text != "")
            {
                SqlConnection con = new SqlConnection(connectrionString);
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "INSERT INTO Client VALUES (@FIO_Client, @Telephone_Client, @Email_Client)";
                cmd.Parameters.Add("FIO_Client", SqlDbType.NVarChar).Value = FIO.Text;
                cmd.Parameters.Add("Telephone_Client", SqlDbType.NVarChar).Value = Telephone_Client.Text;
                cmd.Parameters.Add("Email_Client", SqlDbType.NVarChar).Value = Email_Client.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Данные успешно сохранены");
                con.Close();
                Actions actions = new Actions();
                Hide();
                actions.ShowDialog();
                Show();
            }
            else
            {
                MessageBox.Show("Не все данные были заполнены!\nПожалуйста заполните их");
            }
        }
    }
}
